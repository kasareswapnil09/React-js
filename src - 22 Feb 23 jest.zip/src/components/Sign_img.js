import React from "react";

const SIgn_img = () => {
  return (
    <>
      {/* <div>SIgn_img</div> */}
      <div className="right_data mt-5" style={{ width: "100%" }}>
        <div className="sign_img mt-5">
          <img src="download.jpg" style={{ maxWidth: 500 }} alt=""></img>
        </div>
      </div>
    </>
  );
};
export default SIgn_img;
