// config.js

// export const API_URL = 'http://localhost:3000';
export const API_URL = '  http://localhost:3000/users/';